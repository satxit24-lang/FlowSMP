# Flow SMP - port Paper 1.21.11

Port do add-on Bedrock "Flow SMP v1" (sparklyy1) para Paper 1.21.11.

## Compilar
Requer JDK 21 e Maven:
    mvn package
O jar sai em target/FlowSMP-1.0.0.jar -> coloque em plugins/.

## Uso
- Vista peças com armor trim. A COR (material) do trim define a habilidade; o padrão não importa.
- 2 peças da mesma cor = passiva; 4 = ultimate (configurável).
- Ultimate: agachar + botão direito com um item (ou /ability).
- /flowsmphelp [habilidade], /flowconfig list|get|set|reload, /resetflowconfigs (permissão flowsmp.admin).
- Ícones: opcional. Use FlowSMP-ResourcePack.zip e ative flow.use_resource_pack_icons no config.yml.

## O que mudou em relação ao Bedrock
- Trims são nativos no Java: não precisa de trim_storage, /trim, /makenetherite nem bloqueio da smithing table.
- Formulários (ConfigUI/HelpUI) viraram comandos de chat.
- ShieldCompat (escudos custom) removido; machado-como-mace do Diamond reimplementado.

## Compilar sem instalar nada (GitHub)
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta (inclui .github/workflows/build.yml).
2. Aba Actions -> workflow "Build FlowSMP" (ou Run workflow).
3. Quando terminar, baixe o artefato "FlowSMP-jar": dentro está o FlowSMP-1.0.0.jar.
