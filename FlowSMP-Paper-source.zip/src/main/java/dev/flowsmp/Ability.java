package dev.flowsmp;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;

public enum Ability {
    DIAMOND("diamond", "#2CBAA8", '\uE100'),
    IRON("iron", "#CECACA", '\uE101'),
    RESIN("resin", "#FC7812", '\uE102'),
    COPPER("copper", "#B4684D", '\uE103'),
    NETHERITE("netherite", "#7A6E6F", '\uE104'),
    AMETHYST("amethyst", "#9A5CC6", '\uE105'),
    REDSTONE("redstone", "#C42A15", '\uE106'),
    GOLD("gold", "#DEB12D", '\uE107'),
    QUARTZ("quartz", "#E3D4C4", '\uE108'),
    EMERALD("emerald", "#47A036", '\uE109'),
    LAPIS("lapis", "#3E6BB0", '\uE10A');

    private static final Key ICON_FONT = Key.key("flow", "icons");
    private final String id;
    private final TextColor color;
    private final char icon;

    Ability(String id, String hex, char icon) {
        this.id = id;
        this.color = TextColor.fromHexString(hex);
        this.icon = icon;
    }

    public String id() { return id; }
    public TextColor color() { return color; }
    public String displayName() { return id.substring(0, 1).toUpperCase() + id.substring(1); }

    public static Ability fromTrimKey(String key) {
        for (Ability a : values()) if (a.id.equals(key)) return a;
        return null;
    }

    public static Ability fromId(String id) {
        return id == null ? null : fromTrimKey(id.toLowerCase());
    }

    public Component prefix(boolean icons) {
        if (!icons) return Component.empty();
        return Component.text(String.valueOf(icon)).font(ICON_FONT).color(NamedTextColor.WHITE).append(Component.text(" "));
    }

    public Component label(boolean icons) {
        return prefix(icons).append(Component.text(id.toUpperCase(), color).decorate(net.kyori.adventure.text.format.TextDecoration.BOLD));
    }
}
