package dev.flowsmp;

import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import java.util.UUID;

public abstract class AbilityHandler implements Listener {
    protected final FlowSMP plugin;

    protected AbilityHandler(FlowSMP plugin) { this.plugin = plugin; }

    public abstract Ability ability();
    /** Executa o ultimate; chame done quando terminar (para a mensagem de fim). */
    public abstract void runUltimate(Player p, Runnable done);

    public void applyPassive(Player p) {}
    public void removePassive(Player p) {}
    public boolean meetsRequirement(Player p) { return true; }
    public String requirementMessage() { return ""; }
    public void onQuit(UUID id) {}
    public void shutdown() {}

    protected double d(String key) { return plugin.d(ability(), key); }
    protected int i(String key) { return plugin.i(ability(), key); }
    protected boolean b(String key) { return plugin.b(ability(), key); }
    protected boolean hasPassive(Player p) { return plugin.hasPassive(p, ability()); }
    protected int ticks(String durationKey) { return (int) Math.round(d(durationKey) * Util.TPS); }
}
