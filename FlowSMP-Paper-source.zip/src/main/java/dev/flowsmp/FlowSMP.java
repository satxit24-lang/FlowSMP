package dev.flowsmp;

import dev.flowsmp.abilities.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

public final class FlowSMP extends JavaPlugin implements Listener {
    private final Map<Ability, AbilityHandler> handlers = new EnumMap<>(Ability.class);
    private final Map<UUID, Map<Ability, Long>> cooldowns = new HashMap<>();
    private final Map<UUID, Ability> passives = new HashMap<>();
    private final Map<UUID, Set<PotionEffectType>> givenEffects = new HashMap<>();
    private final Map<UUID, Integer> lastTrigger = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        for (AbilityHandler h : List.of(new DiamondAbility(this), new IronAbility(this), new ResinAbility(this),
                new CopperAbility(this), new NetheriteAbility(this), new AmethystAbility(this),
                new RedstoneAbility(this), new GoldAbility(this), new QuartzAbility(this),
                new EmeraldAbility(this), new LapisAbility(this))) {
            handlers.put(h.ability(), h);
            Bukkit.getPluginManager().registerEvents(h, this);
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::updatePassives, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, this::tickCooldowns, 10L, 10L);
    }

    @Override
    public void onDisable() {
        for (AbilityHandler h : handlers.values()) h.shutdown();
    }

    public AbilityHandler handler(Ability a) { return handlers.get(a); }

    // ---------------- config ----------------
    public double d(Ability a, String k) { return getConfig().getDouble("abilities." + a.id() + "." + k); }
    public int i(Ability a, String k) { return getConfig().getInt("abilities." + a.id() + "." + k); }
    public boolean b(Ability a, String k) { return getConfig().getBoolean("abilities." + a.id() + "." + k); }
    public int flowInt(String k) { return getConfig().getInt("flow." + k); }
    public boolean flowBool(String k) { return getConfig().getBoolean("flow." + k); }
    public boolean icons() { return flowBool("use_resource_pack_icons"); }

    // ---------------- passivas ----------------
    public boolean hasPassive(Player p, Ability a) { return passives.get(p.getUniqueId()) == a; }

    public void giveEffect(Player p, PotionEffectType type, int level) {
        if (level <= 0) return;
        PotionEffect cur = p.getPotionEffect(type);
        if (cur != null && cur.getAmplifier() >= level - 1 && (cur.isInfinite() || cur.getDuration() > 100)) return;
        p.addPotionEffect(new PotionEffect(type, 200, level - 1, false, false, true));
        givenEffects.computeIfAbsent(p.getUniqueId(), k -> new HashSet<>()).add(type);
    }

    private void takeGivenEffects(Player p) {
        for (PotionEffectType t : givenEffects.getOrDefault(p.getUniqueId(), Set.of())) {
            PotionEffect e = p.getPotionEffect(t);
            if (e != null && !e.isInfinite() && e.getDuration() <= 200) p.removePotionEffect(t);
        }
        givenEffects.remove(p.getUniqueId());
    }

    private void updatePassives() {
        for (Player p : Bukkit.getOnlinePlayers()) updatePassive(p);
    }

    private void updatePassive(Player p) {
        if (p.isDead()) return;
        TrimService.TrimSet set = TrimService.getTrimSet(p);
        Ability now = (set != null && set.pieces() >= flowInt("passive_trim_pieces_required")) ? set.ability() : null;
        Ability before = passives.get(p.getUniqueId());
        if (before != now) {
            if (before != null) handlers.get(before).removePassive(p);
            takeGivenEffects(p);
            if (now == null) passives.remove(p.getUniqueId()); else passives.put(p.getUniqueId(), now);
        }
        if (now != null) handlers.get(now).applyPassive(p);
    }

    // ---------------- cooldowns ----------------
    private boolean onCooldown(Player p, Ability a) {
        Long end = cooldowns.getOrDefault(p.getUniqueId(), Map.of()).get(a);
        return end != null && end > System.currentTimeMillis();
    }

    private int remainingSeconds(Player p, Ability a) {
        Long end = cooldowns.getOrDefault(p.getUniqueId(), Map.of()).get(a);
        return end == null ? 0 : (int) Math.max(0, Math.ceil((end - System.currentTimeMillis()) / 1000.0));
    }

    private void tickCooldowns() {
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            Map<Ability, Long> map = cooldowns.get(p.getUniqueId());
            if (map == null) continue;
            Iterator<Map.Entry<Ability, Long>> it = map.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<Ability, Long> en = it.next();
                if (en.getValue() <= now) {
                    it.remove();
                    p.sendMessage(en.getKey().prefix(icons()).append(Component.text("OFF COOLDOWN", en.getKey().color(), TextDecoration.BOLD)));
                    Util.sound(p, "entity.experience_orb.pickup");
                }
            }
            if (map.isEmpty()) cooldowns.remove(p.getUniqueId());
        }
        if (!flowBool("display_cooldown_in_actionbar") || (Bukkit.getCurrentTick() % 20) >= 10) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            TrimService.TrimSet set = TrimService.getTrimSet(p);
            if (set == null || !onCooldown(p, set.ability())) continue;
            int s = remainingSeconds(p, set.ability());
            p.sendActionBar(set.ability().prefix(icons()).append(Component.text(String.format("%d:%02d", s / 60, s % 60), set.ability().color())));
        }
    }

    // ---------------- ultimate ----------------
    public void runUltimate(Player p) {
        TrimService.TrimSet set = TrimService.getTrimSet(p);
        if (set == null) { p.sendMessage("§cYou need to wear trimmed armor to use an ultimate!"); return; }
        Ability a = set.ability();
        AbilityHandler h = handlers.get(a);
        int missing = flowInt("ultimate_trim_pieces_required") - set.pieces();
        if (missing > 0) {
            p.sendMessage("§cYou need to wear §6" + missing + " §cmore §f" + a.displayName() + " §ctrim piece(s) to use your ultimate!");
            return;
        }
        if (!h.meetsRequirement(p)) { p.sendMessage("§c" + h.requirementMessage()); return; }
        if (onCooldown(p, a)) { p.sendMessage("§cYou are on cooldown for the next " + remainingSeconds(p, a) + "s."); return; }

        boolean announce = flowBool("announce_ultimates");
        double duration = d(a, "ultimate_duration");
        if (announce) {
            Component msg = Component.text("You activated your ", NamedTextColor.GREEN).append(a.label(icons()))
                    .append(Component.text(" ultimate!", NamedTextColor.GREEN));
            if (duration > 0) msg = msg.append(Component.text(" It is active for the next " + (int) duration + "s.", NamedTextColor.GRAY));
            p.sendMessage(msg);
            Util.sound(p, "block.beacon.activate");
        }
        h.runUltimate(p, () -> {
            if (announce && duration > 0 && p.isOnline()) {
                p.sendMessage(Component.text("Your ", NamedTextColor.RED).append(a.label(icons()))
                        .append(Component.text(" ultimate is no longer active.", NamedTextColor.RED)));
                Util.sound(p, "block.beacon.deactivate");
            }
        });
        double cd = d(a, "cooldown");
        if (cd > 0) cooldowns.computeIfAbsent(p.getUniqueId(), k -> new EnumMap<>(Ability.class)).put(a, System.currentTimeMillis() + (long) (cd * 1000));
    }

    private void attempt(Player p, String trigger) {
        if (flowBool("require_crouching_to_trigger_abilities") && !p.isSneaking()) return;
        if (!flowBool(trigger + "_to_trigger_abilities")) return;
        TrimService.TrimSet set = TrimService.getTrimSet(p);
        if (set == null || set.pieces() < flowInt("ultimate_trim_pieces_required")) return;
        int tick = Bukkit.getCurrentTick();
        Integer last = lastTrigger.get(p.getUniqueId());
        if (last != null && tick - last < 3) return;
        lastTrigger.put(p.getUniqueId(), tick);
        runUltimate(p);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND || e.getItem() == null) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        attempt(e.getPlayer(), "use_item");
    }

    @EventHandler
    public void onSwing(PlayerAnimationEvent e) {
        attempt(e.getPlayer(), "hit");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        passives.remove(id);
        givenEffects.remove(id);
        lastTrigger.remove(id);
        for (AbilityHandler h : handlers.values()) h.onQuit(id);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!flowBool("show_join_message")) return;
        e.getPlayer().sendMessage("§aFlow SMP\n§7Use §a/flowsmphelp §7para mais informações.\n§7Add-on original por sparklyy1 (port para Paper).");
    }

    // ---------------- comandos ----------------
    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase()) {
            case "ability" -> {
                if (s instanceof Player p) runUltimate(p); else s.sendMessage("§cApenas jogadores.");
            }
            case "flowsmphelp" -> HelpCommand.show(this, s, args);
            case "resetflowconfigs" -> {
                saveResource("config.yml", true);
                reloadConfig();
                s.sendMessage("§aConfig restaurada para o padrão.");
            }
            case "flowconfig" -> flowConfig(s, args);
            default -> { return false; }
        }
        return true;
    }

    private void flowConfig(CommandSender s, String[] args) {
        String sub = args.length > 0 ? args[0].toLowerCase() : "list";
        switch (sub) {
            case "reload" -> { reloadConfig(); s.sendMessage("§aConfig recarregada."); }
            case "list" -> {
                String section = args.length > 1 ? "abilities." + args[1].toLowerCase() : "flow";
                if (getConfig().getConfigurationSection(section) == null) { s.sendMessage("§cSeção inválida. Use: /flowconfig list [habilidade]"); return; }
                s.sendMessage("§6" + section + ":");
                for (String k : getConfig().getConfigurationSection(section).getKeys(false))
                    s.sendMessage("§7- §f" + section + "." + k + " §7= §a" + getConfig().get(section + "." + k));
            }
            case "get" -> {
                if (args.length < 2) { s.sendMessage("§cUso: /flowconfig get <caminho>"); return; }
                s.sendMessage("§f" + args[1] + " §7= §a" + getConfig().get(args[1]));
            }
            case "set" -> {
                if (args.length < 3) { s.sendMessage("§cUso: /flowconfig set <caminho> <valor>"); return; }
                Object def = getConfig().getDefaults() == null ? null : getConfig().getDefaults().get(args[1]);
                if (def == null) { s.sendMessage("§cCaminho desconhecido. Use /flowconfig list."); return; }
                try {
                    Object v;
                    if (def instanceof Boolean) v = Boolean.parseBoolean(args[2]);
                    else if (def instanceof Integer) v = Double.parseDouble(args[2]) % 1 == 0 ? (Object) (int) Double.parseDouble(args[2]) : (Object) Double.parseDouble(args[2]);
                    else v = Double.parseDouble(args[2]);
                    getConfig().set(args[1], v);
                    saveConfig();
                    s.sendMessage("§aSalvo: §f" + args[1] + " §7= §a" + v);
                } catch (NumberFormatException ex) {
                    s.sendMessage("§cValor inválido.");
                }
            }
            default -> s.sendMessage("§cUso: /flowconfig <list [habilidade]|get|set|reload>");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] args) {
        String name = cmd.getName().toLowerCase();
        List<String> out = new ArrayList<>();
        if (name.equals("flowsmphelp") && args.length == 1) {
            for (Ability a : Ability.values()) out.add(a.id());
        } else if (name.equals("flowconfig")) {
            if (args.length == 1) out.addAll(List.of("list", "get", "set", "reload"));
            else if (args.length == 2 && args[0].equalsIgnoreCase("list")) { for (Ability a : Ability.values()) out.add(a.id()); }
            else if (args.length == 2 && (args[0].equalsIgnoreCase("get") || args[0].equalsIgnoreCase("set"))) {
                if (getConfig().getDefaults() != null) out.addAll(getConfig().getDefaults().getKeys(true).stream().filter(k -> getConfig().get(k) != null && !getConfig().isConfigurationSection(k)).toList());
            }
        }
        String prefix = args.length == 0 ? "" : args[args.length - 1].toLowerCase();
        return out.stream().filter(x -> x.toLowerCase().startsWith(prefix)).toList();
    }
}
