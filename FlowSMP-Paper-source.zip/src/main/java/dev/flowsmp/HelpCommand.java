package dev.flowsmp;

import org.bukkit.command.CommandSender;

import java.util.ArrayList;
import java.util.List;

public final class HelpCommand {
    private HelpCommand() {}

    private static String secs(double total) {
        int t = (int) Math.round(total);
        int m = t / 60, s = t % 60;
        if (m == 0) return s + "s";
        if (s == 0) return m + "m";
        return m + "m " + s + "s";
    }

    private static String hearts(double h) { return h == 1 ? "1 heart" : trim(h) + " hearts"; }
    private static String trim(double v) { return v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v); }

    public static void show(FlowSMP plugin, CommandSender s, String[] args) {
        Ability a = args.length > 0 ? Ability.fromId(args[0]) : null;
        if (a == null) {
            s.sendMessage("§a§lFlow SMP §7- o que cada armor trim faz");
            s.sendMessage("§7Passiva: §f" + plugin.flowInt("passive_trim_pieces_required") + " peças §7com a mesma cor de trim. Ultimate: §f" + plugin.flowInt("ultimate_trim_pieces_required") + " peças§7. Ative agachado + botão direito (ou /ability).");
            for (Ability ab : Ability.values()) {
                List<String>[] x = lines(plugin, ab);
                s.sendMessage(net.kyori.adventure.text.Component.text("\n" + ab.displayName().toUpperCase() + " §7(cooldown " + secs(plugin.d(ab, "cooldown")) + ")", ab.color()).decorate(net.kyori.adventure.text.format.TextDecoration.BOLD));
                for (String l : x[0]) s.sendMessage("§aP §f" + l);
                for (String l : x[1]) s.sendMessage("§cU §f" + l);
            }
            s.sendMessage("\n§7P = passiva, U = ultimate. Detalhes: §f/flowsmphelp <habilidade>§7. Admin: §f/flowconfig§7, §f/resetflowconfigs");
            return;
        }
        List<String>[] pu = lines(plugin, a);
        s.sendMessage("§6§l" + a.displayName().toUpperCase());
        s.sendMessage("§lPASSIVE:");
        for (String l : pu[0]) s.sendMessage("§6- §f" + l);
        s.sendMessage("§lULTIMATE:");
        for (String l : pu[1]) s.sendMessage("§6- §f" + l);
        s.sendMessage("§7Cooldown: §f" + secs(plugin.d(a, "cooldown")));
    }

    @SuppressWarnings("unchecked")
    private static List<String>[] lines(FlowSMP p, Ability a) {
        List<String> pas = new ArrayList<>(), ult = new ArrayList<>();
        switch (a) {
            case DIAMOND -> {
                pas.add("Permanent Speed " + p.i(a, "passive_speed_level"));
                if (p.b(a, "passive_axe_acts_as_mace")) pas.add("Your axe smashes like a mace when you hit while falling");
                ult.add("Dash forward in the direction you're looking");
                ult.add("For " + secs(p.d(a, "ultimate_duration")) + " everything within " + trim(p.d(a, "ultimate_field_radius")) + " blocks gets Slowness " + p.i(a, "ultimate_slowness_level"));
            }
            case IRON -> {
                if (p.b(a, "passive_invisibility")) pas.add("You are permanently invisible");
                pas.add("Every " + p.i(a, "passive_hit_requirement") + " hits mark your target with a pillar of particles for " + secs(p.d(a, "passive_mark_duration")));
                ult.add("An explosion deals " + trim(p.d(a, "ultimate_explosion_damage")) + " damage within " + trim(p.d(a, "ultimate_explosion_radius")) + " blocks");
                ult.add("You turn truly invisible for " + secs(p.d(a, "ultimate_duration")) + ", hiding armor and held item too");
            }
            case RESIN -> {
                if (p.b(a, "passive_fire_resistance")) pas.add("Permanent Fire Resistance");
                pas.add("Your hits deal +" + trim(p.d(a, "passive_burning_damage_bonus")) + " damage while you are on fire");
                ult.add("Drain all water within " + trim(p.d(a, "ultimate_drain_radius")) + " blocks");
                ult.add("Fire beam for " + secs(p.d(a, "ultimate_duration")) + ", range " + trim(p.d(a, "ultimate_beam_range")) + " blocks");
                ult.add(trim(p.d(a, "ultimate_beam_damage")) + " damage twice a second and burns targets for " + secs(p.d(a, "ultimate_burn_duration")));
            }
            case COPPER -> {
                pas.add(hearts(p.d(a, "passive_extra_hearts")) + " more health");
                pas.add("Every " + p.i(a, "passive_hit_requirement") + " hits heal you " + hearts(p.d(a, "passive_heal_hearts")));
                ult.add("Steal " + hearts(p.d(a, "ultimate_steal_hearts")) + " from the closest target within " + trim(p.d(a, "ultimate_range")) + " blocks");
                ult.add("Then drain " + hearts(p.d(a, "ultimate_drain_hearts")) + " more over " + secs(p.d(a, "ultimate_duration")) + " while they stay in range");
            }
            case NETHERITE -> {
                pas.add("Permanent Resistance " + p.i(a, "passive_resistance_level"));
                if (p.b(a, "passive_forge_diamond_armor")) { pas.add("Diamond armor you wear turns into netherite"); pas.add("It turns back if you take it off or die"); }
                ult.add("Pull the closest target within " + trim(p.d(a, "ultimate_pull_range")) + " blocks into an obsidian dome for " + secs(p.d(a, "ultimate_duration")));
                ult.add("The first " + p.i(a, "ultimate_invincible_hits") + " hits you take are blocked");
                ult.add("The dome disappears early if you die or leave it");
            }
            case AMETHYST -> {
                pas.add("Permanent Regeneration " + p.i(a, "passive_regeneration_level"));
                pas.add(hearts(p.d(a, "passive_absorption_hearts")) + " of absorption every " + secs(p.d(a, "passive_absorption_interval")));
                pas.add("Cobwebs within " + trim(p.d(a, "passive_cobweb_radius")) + " blocks are consumed and heal you " + hearts(p.d(a, "passive_cobweb_heal_hearts")) + " each");
                ult.add("For " + secs(p.d(a, "ultimate_duration")) + " you take no damage at all");
                ult.add("Attackers take " + trim(p.d(a, "ultimate_reflect_multiplier")) + "x that damage instead");
            }
            case REDSTONE -> {
                pas.add("Permanent Strength " + p.i(a, "passive_strength_level"));
                pas.add("Crossbow arrows hit as if it had Power " + p.i(a, "passive_crossbow_power_level"));
                ult.add("Sonic boom through walls: " + trim(p.d(a, "ultimate_beam_damage")) + " damage up to " + trim(p.d(a, "ultimate_beam_range")) + " blocks");
                ult.add("For " + secs(p.d(a, "ultimate_duration")) + " every hit is a crit dealing " + trim(p.d(a, "ultimate_crit_damage_multiplier")) + "x damage");
            }
            case GOLD -> {
                pas.add("Permanent Haste " + p.i(a, "passive_haste_level"));
                pas.add("Every " + p.i(a, "passive_hit_requirement") + " hits strike your target with lightning");
                if (p.b(a, "passive_lightning_immunity")) pas.add("Lightning can't hurt you");
                ult.add((p.b(a, "ultimate_set_weather") ? "Summon a thunderstorm for " : "For the next ") + secs(p.d(a, "ultimate_duration")));
                ult.add("Every " + trim(p.d(a, "ultimate_strike_interval")) + "s lightning strikes up to " + p.i(a, "ultimate_targets_per_strike") + " targets within " + trim(p.d(a, "ultimate_strike_radius")) + " blocks");
            }
            case QUARTZ -> {
                pas.add("Permanent Weaving " + p.i(a, "passive_weaving_level"));
                pas.add("Your hits deal " + trim(p.d(a, "passive_cobweb_damage_multiplier")) + "x damage to anything standing in a cobweb");
                ult.add("Pull the closest target within " + trim(p.d(a, "ultimate_pull_range")) + " blocks to you");
                ult.add("They get stuck in a cobweb at their feet, or head if feet are blocked");
            }
            case EMERALD -> {
                pas.add("Permanent Hero of the Village " + p.i(a, "passive_hero_of_the_village_level"));
                pas.add(p.i(a, "passive_anvil_refund_percentage") + " percent of levels spent at an anvil are given back");
                ult.add("Worn armor gets Protection " + p.i(a, "ultimate_protection_level") + " and Unbreaking " + p.i(a, "ultimate_unbreaking_level"));
                ult.add("Hotbar of every player within " + trim(p.d(a, "ultimate_scramble_radius")) + " blocks is scrambled");
            }
            case LAPIS -> {
                pas.add(trim(p.d(a, "passive_xp_multiplier")) + "x experience");
                pas.add("Every " + secs(p.d(a, "passive_mend_interval")) + " a random damaged armor piece is repaired by " + p.i(a, "passive_mend_durability") + " durability");
                ult.add("The item you are holding gets its best enchantments at max level");
            }
        }
        return new List[]{pas, ult};
    }
}
