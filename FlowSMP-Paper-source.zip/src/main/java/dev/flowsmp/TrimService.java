package dev.flowsmp;

import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.entity.Player;

import java.util.EnumMap;
import java.util.Map;

public final class TrimService {
    private TrimService() {}

    public record TrimSet(Ability ability, int pieces) {}

    public static Ability abilityOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta instanceof ArmorMeta am && am.hasTrim()) {
            return Ability.fromTrimKey(am.getTrim().getMaterial().getKey().getKey());
        }
        return null;
    }

    /** A cor de trim vestida em mais peças decide a habilidade (o padrão do trim não importa). */
    public static TrimSet getTrimSet(Player p) {
        Map<Ability, Integer> counts = new EnumMap<>(Ability.class);
        Ability best = null;
        for (ItemStack item : p.getInventory().getArmorContents()) {
            Ability a = abilityOf(item);
            if (a == null) continue;
            counts.merge(a, 1, Integer::sum);
            if (best == null || counts.get(a) > counts.get(best)) best = a;
        }
        return best == null ? null : new TrimSet(best, counts.get(best));
    }
}
