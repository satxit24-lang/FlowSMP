package dev.flowsmp;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.damage.DamageSource;
import org.bukkit.damage.DamageType;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.function.IntPredicate;
import java.util.function.Predicate;

public final class Util {
    private Util() {}

    public static final int TPS = 20;
    public static final double HEART = 2.0;

    public static boolean alive(Player p) {
        return p != null && p.isOnline() && !p.isDead();
    }

    public static boolean targetable(Entity e, Player self) {
        if (!(e instanceof LivingEntity le) || e instanceof ArmorStand || e.equals(self) || le.isDead()) return false;
        if (e instanceof Player p) return p.getGameMode() != GameMode.CREATIVE && p.getGameMode() != GameMode.SPECTATOR;
        return true;
    }

    public static List<LivingEntity> nearbyTargets(Player p, double radius) {
        Location loc = p.getLocation();
        List<LivingEntity> out = new ArrayList<>();
        for (Entity e : p.getWorld().getNearbyEntities(loc, radius, radius, radius)) {
            if (e instanceof LivingEntity le && targetable(e, p) && e.getLocation().distanceSquared(loc) <= radius * radius) out.add(le);
        }
        return out;
    }

    public static List<Player> nearbyPlayers(Player p, double radius) {
        List<Player> out = new ArrayList<>();
        for (LivingEntity e : nearbyTargets(p, radius)) if (e instanceof Player pl) out.add(pl);
        return out;
    }

    private static LivingEntity closest(Collection<? extends LivingEntity> list, Location from) {
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            double d = e.getLocation().distanceSquared(from);
            if (d < bestD) { bestD = d; best = e; }
        }
        return best;
    }

    public static LivingEntity findTarget(Player p, double range) {
        List<LivingEntity> targets = nearbyTargets(p, range);
        List<LivingEntity> players = new ArrayList<>();
        for (LivingEntity e : targets) if (e instanceof Player) players.add(e);
        LivingEntity c = closest(players, p.getLocation());
        return c != null ? c : closest(targets, p.getLocation());
    }

    public static void knockAway(Entity e, Location origin, double strength) {
        Vector off = e.getLocation().toVector().subtract(origin.toVector());
        double dist = Math.hypot(off.getX(), off.getZ());
        if (dist == 0) return;
        e.setVelocity(new Vector(off.getX() / dist * strength, 0.4, off.getZ() / dist * strength));
    }

    public static void heal(LivingEntity e, double amount) {
        if (e.isDead() || e.getHealth() <= 0) return;
        AttributeInstance a = e.getAttribute(Attribute.MAX_HEALTH);
        double max = a != null ? a.getValue() : e.getHealth() + amount;
        e.setHealth(Math.min(max, e.getHealth() + amount));
    }

    public static void damage(LivingEntity target, double amount, DamageType type, Entity source) {
        DamageSource ds = DamageSource.builder(type).withCausingEntity(source).withDirectEntity(source).build();
        target.damage(amount, ds);
    }

    public static Player meleeAttacker(EntityDamageByEntityEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return null;
        if (e.getDamager() instanceof Player p && !p.equals(e.getEntity())) return p;
        return null;
    }

    public static Enchantment enchant(String key) {
        return Registry.ENCHANTMENT.get(NamespacedKey.minecraft(key));
    }

    public static int enchantLevel(ItemStack item, String key) {
        Enchantment e = enchant(key);
        return (item == null || e == null) ? 0 : item.getEnchantmentLevel(e);
    }

    public static void effect(LivingEntity e, PotionEffectType type, int level, int ticks, boolean particles) {
        if (level <= 0 || ticks <= 0) return;
        e.addPotionEffect(new PotionEffect(type, ticks, level - 1, false, particles, true));
    }

    public static void sound(Location loc, String key) {
        loc.getWorld().playSound(loc, "minecraft:" + key, SoundCategory.PLAYERS, 1f, 1f);
    }

    public static void sound(Player p, String key) {
        p.playSound(p.getLocation(), "minecraft:" + key, SoundCategory.PLAYERS, 1f, 1f);
    }

    public static void particle(Location loc, Particle particle) {
        loc.getWorld().spawnParticle(particle, loc, 1, 0, 0, 0, 0);
    }

    public static void ring(Location center, double radius, Particle particle) {
        int points = (int) Math.max(8, Math.round(2 * Math.PI * radius));
        for (int i = 0; i < points; i++) {
            double a = (i / (double) points) * 2 * Math.PI;
            particle(center.clone().add(Math.cos(a) * radius, 0, Math.sin(a) * radius), particle);
        }
    }

    public static int replaceNearby(Location center, double radius, Predicate<Block> match, Material replacement) {
        World w = center.getWorld();
        int r = (int) Math.min(Math.floor(radius), 15);
        if (r < 0) return 0;
        int count = 0;
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            int bx = center.getBlockX() + x, by = center.getBlockY() + y, bz = center.getBlockZ() + z;
            if (by < w.getMinHeight() || by >= w.getMaxHeight() || !w.isChunkLoaded(bx >> 4, bz >> 4)) continue;
            Block b = w.getBlockAt(bx, by, bz);
            if (match.test(b)) { b.setType(replacement, false); count++; }
        }
        return count;
    }

    public static void setEquipmentHidden(Player target, boolean hidden) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.HAND, EquipmentSlot.OFF_HAND};
        for (Player viewer : target.getWorld().getPlayers()) {
            if (viewer.equals(target)) continue;
            for (EquipmentSlot s : slots) {
                ItemStack item = hidden ? new ItemStack(Material.AIR) : target.getInventory().getItem(s);
                viewer.sendEquipmentChange(target, s, item);
            }
        }
    }

    /** Roda body em t=0 e a cada interval ticks enquanto t < duration e body retornar true; depois chama end. */
    public static void every(Plugin plugin, int interval, int duration, IntPredicate body, Runnable end) {
        new BukkitRunnable() {
            int t = 0;
            @Override public void run() {
                if (t >= duration || !body.test(t)) {
                    cancel();
                    if (end != null) end.run();
                    return;
                }
                t += interval;
            }
        }.runTaskTimer(plugin, 0L, interval);
    }

    // ---------- Beam ----------
    public record Beam(Location origin, Vector direction, double length) {
        public static Beam of(Player p, double range, boolean throughBlocks) {
            Location o = p.getEyeLocation();
            Vector d = o.getDirection().normalize();
            double len = range;
            if (!throughBlocks) {
                RayTraceResult r = p.getWorld().rayTraceBlocks(o, d, range, FluidCollisionMode.NEVER, true);
                if (r != null) len = r.getHitPosition().distance(o.toVector());
            }
            return new Beam(o, d, len);
        }

        public static Beam between(Location from, Location to) {
            double len = from.distance(to);
            return new Beam(from, to.toVector().subtract(from.toVector()).multiply(1.0 / (len == 0 ? 1 : len)), len);
        }

        public static Location body(Entity e) { return e.getLocation().add(0, 0.9, 0); }

        public List<LivingEntity> targets(Player p, double width) {
            List<LivingEntity> out = new ArrayList<>();
            for (LivingEntity e : nearbyTargets(p, length + width)) {
                Vector off = body(e).toVector().subtract(origin.toVector());
                double along = off.dot(direction);
                if (along < 0 || along > length) continue;
                if (off.clone().subtract(direction.clone().multiply(along)).length() <= width) out.add(e);
            }
            return out;
        }

        public void draw(Particle particle, double spacing, double spread) {
            Random rnd = new Random();
            for (double d = 1; d <= length; d += spacing) {
                Location pt = origin.clone().add(direction.clone().multiply(d));
                if (spread > 0) pt.add((rnd.nextDouble() - 0.5) * 2 * spread, (rnd.nextDouble() - 0.5) * 2 * spread, (rnd.nextDouble() - 0.5) * 2 * spread);
                particle(pt, particle);
            }
        }
    }

    public static final class HitCounter {
        private final Map<UUID, Integer> hits = new HashMap<>();
        public boolean count(UUID id, int requirement) {
            int n = hits.merge(id, 1, Integer::sum);
            if (n < requirement) return false;
            hits.put(id, 0);
            return true;
        }
        public void clear(UUID id) { hits.remove(id); }
    }
}
