package dev.flowsmp.abilities;

import dev.flowsmp.*;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.potion.PotionEffectType;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class AmethystAbility extends AbilityHandler {
    private final Set<UUID> deflecting = new HashSet<>();
    public AmethystAbility(FlowSMP plugin) { super(plugin); }
    @Override public Ability ability() { return Ability.AMETHYST; }

    @Override public void applyPassive(Player p) {
        plugin.giveEffect(p, PotionEffectType.REGENERATION, i("passive_regeneration_level"));
        if (!p.hasPotionEffect(PotionEffectType.ABSORPTION)) {
            Util.effect(p, PotionEffectType.ABSORPTION, (int) Math.floor(d("passive_absorption_hearts") / 2), (int) (d("passive_absorption_interval") * Util.TPS), false);
        }
        int drained = Util.replaceNearby(p.getLocation(), d("passive_cobweb_radius"), b -> b.getType() == Material.COBWEB, Material.AIR);
        if (drained > 0) {
            Util.heal(p, drained * d("passive_cobweb_heal_hearts") * Util.HEART);
            Util.particle(p.getEyeLocation(), Particle.HEART);
            Util.sound(p.getLocation(), "entity.player.burp");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player victim) || !deflecting.contains(victim.getUniqueId())) return;
        Entity attacker = null;
        if (e instanceof EntityDamageByEntityEvent be) {
            attacker = be.getDamager();
            if (attacker instanceof Projectile pr && pr.getShooter() instanceof Entity s) attacker = s;
        }
        double damage = e.getDamage() * d("ultimate_reflect_multiplier");
        e.setCancelled(true);
        if (attacker instanceof LivingEntity la && !la.equals(victim) && e.getCause() != EntityDamageEvent.DamageCause.THORNS) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!victim.isOnline() || !la.isValid()) return;
                Util.damage(la, damage, DamageType.THORNS, victim);
                Util.particle(victim.getLocation().add(0, 1, 0), Particle.CRIT);
                Util.sound(victim.getLocation(), "block.amethyst_block.chime");
            });
        }
    }

    @Override
    public void runUltimate(Player p, Runnable done) {
        UUID id = p.getUniqueId();
        deflecting.add(id);
        Util.every(plugin, 10, ticks("ultimate_duration"), t -> {
            if (!Util.alive(p)) return false;
            Util.ring(p.getLocation().add(0, 1, 0), 1, Particle.END_ROD);
            return true;
        }, () -> { deflecting.remove(id); done.run(); });
    }

    @Override public void onQuit(UUID id) { deflecting.remove(id); }
}
