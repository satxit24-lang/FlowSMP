package dev.flowsmp.abilities;

import dev.flowsmp.*;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

public final class CopperAbility extends AbilityHandler {
    private final Util.HitCounter hits = new Util.HitCounter();
    public CopperAbility(FlowSMP plugin) { super(plugin); }
    @Override public Ability ability() { return Ability.COPPER; }

    @Override public void applyPassive(Player p) {
        int level = (int) Math.floor(d("passive_extra_hearts") / 2);
        if (level <= 0) return;
        PotionEffect cur = p.getPotionEffect(PotionEffectType.HEALTH_BOOST);
        if (cur != null && cur.getAmplifier() == level - 1) return;
        p.removePotionEffect(PotionEffectType.HEALTH_BOOST);
        p.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, PotionEffect.INFINITE_DURATION, level - 1, false, false, true));
    }

    @Override public void removePassive(Player p) { p.removePotionEffect(PotionEffectType.HEALTH_BOOST); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        Player att = Util.meleeAttacker(e);
        if (att == null || !hasPassive(att)) return;
        if (hits.count(att.getUniqueId(), i("passive_hit_requirement"))) {
            Util.heal(att, d("passive_heal_hearts") * Util.HEART);
            Util.particle(att.getEyeLocation(), Particle.HEART);
            Util.sound(att, "entity.experience_orb.pickup");
        }
    }

    @Override public boolean meetsRequirement(Player p) { return Util.findTarget(p, d("ultimate_range")) != null; }
    @Override public String requirementMessage() { return "There is nothing close enough to steal hearts from!"; }

    private void steal(Player p, LivingEntity target, double amount) {
        double before = target.getHealth();
        Util.damage(target, amount, DamageType.MAGIC, p);
        if (!target.isDead() && target.getHealth() >= before) return;
        Util.heal(p, amount);
        Util.Beam.between(Util.Beam.body(target), Util.Beam.body(p)).draw(Particle.HEART, 0.75, 0);
        Util.sound(p.getLocation(), "entity.zombie_villager.converted");
    }

    @Override
    public void runUltimate(Player p, Runnable done) {
        LivingEntity target = Util.findTarget(p, d("ultimate_range"));
        if (target == null) { done.run(); return; }
        steal(p, target, d("ultimate_steal_hearts") * Util.HEART);
        int drains = i("ultimate_drain_hearts");
        if (drains <= 0) { done.run(); return; }
        int interval = (int) Math.max(1, Math.round(d("ultimate_duration") * Util.TPS / Math.max(1, drains)));
        new BukkitRunnable() {
            int n = 0;
            @Override public void run() {
                boolean reach = Util.alive(p) && target.isValid() && !target.isDead() && p.getWorld().equals(target.getWorld())
                        && p.getLocation().distance(target.getLocation()) <= d("ultimate_range");
                if (!reach) { cancel(); done.run(); return; }
                steal(p, target, Util.HEART);
                if (++n >= drains) { cancel(); done.run(); }
            }
        }.runTaskTimer(plugin, interval, interval);
    }

    @Override public void onQuit(UUID id) { hits.clear(id); }
}
