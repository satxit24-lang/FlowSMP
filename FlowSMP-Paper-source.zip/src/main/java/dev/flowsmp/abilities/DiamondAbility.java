package dev.flowsmp.abilities;

import dev.flowsmp.*;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Tag;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public final class DiamondAbility extends AbilityHandler {
    public DiamondAbility(FlowSMP plugin) { super(plugin); }
    @Override public Ability ability() { return Ability.DIAMOND; }

    @Override public void applyPassive(Player p) { plugin.giveEffect(p, PotionEffectType.SPEED, i("passive_speed_level")); }

    private double smashDamage(double fall, ItemStack item) {
        double remaining = fall;
        double damage = Util.enchantLevel(item, "density") * 0.5 * fall;
        double[][] tiers = {{3, 4}, {5, 2}, {Double.MAX_VALUE, 1}};
        for (double[] t : tiers) {
            double blocks = Math.min(remaining, t[0]);
            damage += blocks * t[1];
            remaining -= blocks;
        }
        return damage;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        Player att = Util.meleeAttacker(e);
        if (att == null || !hasPassive(att) || !b("passive_axe_acts_as_mace")) return;
        ItemStack held = att.getInventory().getItemInMainHand();
        if (!Tag.ITEMS_AXES.isTagged(held.getType()) || att.isGliding()) return;
        double fall = att.getFallDistance();
        if (fall <= 1.5 || !(e.getEntity() instanceof LivingEntity victim)) return;

        e.setDamage(e.getDamage() + smashDamage(fall, held));
        boolean heavy = fall > 5;
        Location loc = victim.getLocation();
        String sound = !victim.isOnGround() ? "item.mace.smash_air" : (heavy ? "item.mace.smash_ground_heavy" : "item.mace.smash_ground");
        att.setFallDistance(0);
        Bukkit.getScheduler().runTask(plugin, () -> {
            Util.sound(loc, sound);
            for (var n : loc.getWorld().getNearbyEntities(loc, 3.5, 3.5, 3.5)) {
                if (!(n instanceof LivingEntity le) || n.equals(att) || n.equals(victim) || n instanceof org.bukkit.entity.ArmorStand) continue;
                Vector off = n.getLocation().toVector().subtract(loc.toVector());
                double dist = off.length();
                double strength = (3.5 - dist) * 0.7 * (heavy ? 2 : 1);
                if (dist == 0 || strength <= 0) continue;
                off.normalize().multiply(strength);
                le.setVelocity(new Vector(off.getX(), 0.7, off.getZ()));
            }
        });
    }

    @Override
    public void runUltimate(Player p, Runnable done) {
        Vector v = p.getLocation().getDirection().multiply(d("ultimate_dash_strength"));
        v.setY(v.getY() + d("ultimate_dash_lift"));
        p.setVelocity(v);
        Util.sound(p.getLocation(), "entity.ender_dragon.flap");
        Util.particle(p.getLocation(), Particle.CLOUD);
        double radius = d("ultimate_field_radius");
        Util.every(plugin, 10, ticks("ultimate_duration"), t -> {
            if (!Util.alive(p)) return false;
            for (LivingEntity target : Util.nearbyTargets(p, radius)) Util.effect(target, PotionEffectType.SLOWNESS, i("ultimate_slowness_level"), 30, true);
            Util.ring(p.getLocation().add(0, 0.2, 0), radius, Particle.SOUL_FIRE_FLAME);
            return true;
        }, done);
    }
}
