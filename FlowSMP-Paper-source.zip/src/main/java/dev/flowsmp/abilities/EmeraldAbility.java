package dev.flowsmp.abilities;

import dev.flowsmp.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

public final class EmeraldAbility extends AbilityHandler {
    public EmeraldAbility(FlowSMP plugin) { super(plugin); }
    @Override public Ability ability() { return Ability.EMERALD; }

    @Override public void applyPassive(Player p) {
        plugin.giveEffect(p, PotionEffectType.HERO_OF_THE_VILLAGE, i("passive_hero_of_the_village_level"));
    }

    /** Devolve parte dos níveis gastos ao pegar o resultado da bigorna. */
    @EventHandler
    public void onAnvil(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || e.getInventory().getType() != InventoryType.ANVIL) return;
        if (e.getRawSlot() != 2 || !hasPassive(p)) return;
        int before = p.getLevel();
        Bukkit.getScheduler().runTask(plugin, () -> {
            int spent = before - p.getLevel();
            int refund = (int) Math.floor(spent * i("passive_anvil_refund_percentage") / 100.0);
            if (refund <= 0) return;
            p.giveExpLevels(refund);
            p.sendActionBar(Ability.EMERALD.prefix(plugin.icons()).append(Component.text("+" + refund + " LEVELS REFUNDED", Ability.EMERALD.color(), TextDecoration.BOLD)));
            Util.sound(p, "entity.experience_orb.pickup");
        });
    }

    private List<Map.Entry<String, Integer>> armorEnchants() {
        return List.of(Map.entry("protection", i("ultimate_protection_level")), Map.entry("unbreaking", i("ultimate_unbreaking_level")));
    }

    private List<ItemStack> worn(Player p) {
        List<ItemStack> out = new ArrayList<>();
        for (ItemStack it : p.getInventory().getArmorContents()) if (it != null && !it.getType().isAir()) out.add(it);
        return out;
    }

    @Override public boolean meetsRequirement(Player p) {
        if (!Util.nearbyPlayers(p, d("ultimate_scramble_radius")).isEmpty()) return true;
        for (ItemStack it : worn(p)) if (LapisAbility.missing(it, armorEnchants()) > 0) return true;
        return false;
    }
    @Override public String requirementMessage() { return "There is no one nearby to scramble and your armor is already enchanted!"; }

    @Override
    public void runUltimate(Player p, Runnable done) {
        boolean any = false;
        for (ItemStack it : worn(p)) any |= LapisAbility.apply(it, armorEnchants()) > 0;
        if (any) { p.getInventory().setArmorContents(p.getInventory().getArmorContents()); Util.sound(p.getLocation(), "block.enchantment_table.use"); }
        Random rnd = new Random();
        for (Player victim : Util.nearbyPlayers(p, d("ultimate_scramble_radius"))) {
            List<ItemStack> hotbar = new ArrayList<>();
            for (int s = 0; s < 9; s++) hotbar.add(victim.getInventory().getItem(s));
            Collections.shuffle(hotbar, rnd);
            for (int s = 0; s < 9; s++) victim.getInventory().setItem(s, hotbar.get(s));
            victim.sendActionBar(Ability.EMERALD.prefix(plugin.icons()).append(Component.text("YOUR HOTBAR WAS SCRAMBLED", Ability.EMERALD.color(), TextDecoration.BOLD)));
            Util.sound(victim, "entity.enderman.teleport");
        }
        done.run();
    }
}
