package dev.flowsmp.abilities;

import dev.flowsmp.*;
import org.bukkit.World;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

public final class GoldAbility extends AbilityHandler {
    private final Util.HitCounter hits = new Util.HitCounter();
    private final Set<UUID> storming = new HashSet<>();
    public GoldAbility(FlowSMP plugin) { super(plugin); }
    @Override public Ability ability() { return Ability.GOLD; }

    @Override public void applyPassive(Player p) { plugin.giveEffect(p, PotionEffectType.HASTE, i("passive_haste_level")); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        Player att = Util.meleeAttacker(e);
        if (att == null || !hasPassive(att) || !(e.getEntity() instanceof LivingEntity victim)) return;
        if (hits.count(att.getUniqueId(), i("passive_hit_requirement"))) victim.getWorld().strikeLightning(victim.getLocation());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onLightning(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.LIGHTNING || !(e.getEntity() instanceof Player p)) return;
        if (storming.contains(p.getUniqueId()) || (hasPassive(p) && b("passive_lightning_immunity"))) {
            e.setCancelled(true);
            p.setFireTicks(0);
        }
    }

    @Override
    public void runUltimate(Player p, Runnable done) {
        UUID id = p.getUniqueId();
        int duration = ticks("ultimate_duration");
        storming.add(id);
        World w = p.getWorld();
        if (b("ultimate_set_weather") && w.getEnvironment() == World.Environment.NORMAL) {
            w.setStorm(true);
            w.setThundering(true);
            w.setWeatherDuration(duration);
            w.setThunderDuration(duration);
        }
        Util.sound(p.getLocation(), "entity.lightning_bolt.thunder");
        int interval = (int) Math.max(1, Math.round(d("ultimate_strike_interval") * Util.TPS));
        Util.every(plugin, interval, duration, t -> {
            if (!Util.alive(p)) return false;
            List<LivingEntity> targets = Util.nearbyTargets(p, d("ultimate_strike_radius"));
            targets.sort(Comparator.comparing((LivingEntity e) -> !(e instanceof Player)).thenComparingDouble(e -> e.getLocation().distanceSquared(p.getLocation())));
            for (LivingEntity t2 : targets.subList(0, Math.min(targets.size(), i("ultimate_targets_per_strike"))))
                t2.getWorld().strikeLightning(t2.getLocation());
            return true;
        }, () -> { storming.remove(id); done.run(); });
    }

    @Override public void onQuit(UUID id) { hits.clear(id); storming.remove(id); }
}
