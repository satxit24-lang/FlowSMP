package dev.flowsmp.abilities;

import dev.flowsmp.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.damage.DamageType;
import org.bukkit.potion.PotionEffectType;

import java.util.UUID;

public final class IronAbility extends AbilityHandler {
    private final Util.HitCounter hits = new Util.HitCounter();
    public IronAbility(FlowSMP plugin) { super(plugin); }
    @Override public Ability ability() { return Ability.IRON; }

    @Override public void applyPassive(Player p) {
        if (b("passive_invisibility")) plugin.giveEffect(p, PotionEffectType.INVISIBILITY, 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        Player att = Util.meleeAttacker(e);
        if (att == null || !hasPassive(att) || !(e.getEntity() instanceof LivingEntity victim)) return;
        if (!hits.count(att.getUniqueId(), i("passive_hit_requirement"))) return;
        att.sendActionBar(Ability.IRON.prefix(plugin.icons()).append(Component.text("TARGET MARKED", Ability.IRON.color(), TextDecoration.BOLD)));
        Util.sound(att, "entity.experience_orb.pickup");
        int pulses = (int) (d("passive_mark_duration") * Util.TPS / 5);
        Util.every(plugin, 5, pulses * 5, t -> {
            if (!victim.isValid()) return false;
            for (double h : new double[]{2.5, 3, 3.5, 4}) Util.particle(victim.getLocation().add(0, h, 0), Particle.END_ROD);
            return true;
        }, null);
    }

    @Override
    public void runUltimate(Player p, Runnable done) {
        for (LivingEntity t : Util.nearbyTargets(p, d("ultimate_explosion_radius"))) {
            Util.knockAway(t, p.getLocation(), d("ultimate_explosion_knockback"));
            Util.damage(t, d("ultimate_explosion_damage"), DamageType.PLAYER_EXPLOSION, p);
        }
        Util.particle(p.getLocation(), Particle.EXPLOSION_EMITTER);
        Util.sound(p.getLocation(), "entity.generic.explode");
        int duration = ticks("ultimate_duration");
        Util.effect(p, PotionEffectType.INVISIBILITY, 1, duration, false);
        Util.every(plugin, 20, duration, t -> {
            if (!Util.alive(p)) return false;
            Util.setEquipmentHidden(p, true);
            return true;
        }, () -> {
            if (p.isOnline()) Bukkit.getScheduler().runTask(plugin, () -> Util.setEquipmentHidden(p, false));
            done.run();
        });
    }

    @Override public void onQuit(UUID id) { hits.clear(id); }
}
