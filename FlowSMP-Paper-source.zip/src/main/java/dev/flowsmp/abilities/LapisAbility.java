package dev.flowsmp.abilities;

import dev.flowsmp.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.PlayerExpChangeEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public final class LapisAbility extends AbilityHandler {
    private static final Map<String, List<Map.Entry<String, Integer>>> PRESETS = new LinkedHashMap<>();
    private final Map<UUID, Double> leftover = new HashMap<>();
    private final Map<UUID, Long> nextMend = new HashMap<>();

    static {
        PRESETS.put("helmet", l("protection", 4, "unbreaking", 3, "mending", 1, "aqua_affinity", 1, "respiration", 3));
        PRESETS.put("chestplate", l("protection", 4, "unbreaking", 3, "mending", 1));
        PRESETS.put("leggings", l("protection", 4, "unbreaking", 3, "mending", 1, "swift_sneak", 3));
        PRESETS.put("boots", l("protection", 4, "unbreaking", 3, "mending", 1, "feather_falling", 4, "depth_strider", 3));
        PRESETS.put("sword", l("sharpness", 5, "unbreaking", 3, "mending", 1, "fire_aspect", 2, "looting", 3));
        PRESETS.put("pickaxe", l("efficiency", 5, "unbreaking", 3, "mending", 1, "silk_touch", 1));
        PRESETS.put("axe", l("efficiency", 5, "unbreaking", 3, "mending", 1, "sharpness", 5, "silk_touch", 1));
        PRESETS.put("bow", l("power", 5, "unbreaking", 3, "flame", 1, "infinity", 1));
        PRESETS.put("crossbow", l("piercing", 4, "unbreaking", 3, "mending", 1, "quick_charge", 3));
        PRESETS.put("shield", l("unbreaking", 3, "mending", 1));
        PRESETS.put("trident", l("impaling", 5, "unbreaking", 3, "mending", 1, "riptide", 3));
        PRESETS.put("mace", l("density", 5, "unbreaking", 3, "mending", 1, "wind_burst", 1));
        PRESETS.put("spear", l("sharpness", 5, "unbreaking", 3, "mending", 1, "fire_aspect", 2, "looting", 3, "lunge", 3));
        PRESETS.put("shovel", l("efficiency", 5, "unbreaking", 3, "mending", 1, "silk_touch", 1));
        PRESETS.put("hoe", l("efficiency", 5, "unbreaking", 3, "mending", 1, "fortune", 3));
    }

    private static List<Map.Entry<String, Integer>> l(Object... kv) {
        List<Map.Entry<String, Integer>> out = new ArrayList<>();
        for (int i = 0; i < kv.length; i += 2) out.add(Map.entry((String) kv[i], (Integer) kv[i + 1]));
        return out;
    }

    public LapisAbility(FlowSMP plugin) { super(plugin); }
    @Override public Ability ability() { return Ability.LAPIS; }

    // ---- utilitário de encantamentos (usado também pelo Emerald) ----
    private static boolean isMissing(ItemStack item, Enchantment ench, int level) {
        int cur = item.getEnchantmentLevel(ench);
        if (cur > 0) return cur < level;
        if (!ench.canEnchantItem(item)) return false;
        for (Enchantment other : item.getEnchantments().keySet()) if (!other.equals(ench) && other.conflictsWith(ench)) return false;
        return true;
    }

    public static int missing(ItemStack item, List<Map.Entry<String, Integer>> list) {
        if (item == null || item.getType().isAir()) return 0;
        int n = 0;
        for (var en : list) {
            Enchantment e = Util.enchant(en.getKey());
            if (e != null && en.getValue() > 0 && isMissing(item, e, Math.min(en.getValue(), e.getMaxLevel()))) n++;
        }
        return n;
    }

    public static int apply(ItemStack item, List<Map.Entry<String, Integer>> list) {
        if (item == null || item.getType().isAir()) return 0;
        int added = 0;
        for (var en : list) {
            Enchantment e = Util.enchant(en.getKey());
            if (e == null || en.getValue() <= 0) continue;
            int level = Math.min(en.getValue(), e.getMaxLevel());
            if (!isMissing(item, e, level)) continue;
            item.removeEnchantment(e);
            item.addUnsafeEnchantment(e, level);
            added++;
        }
        return added;
    }

    private static List<Map.Entry<String, Integer>> presetFor(ItemStack item) {
        if (item == null) return List.of();
        String name = item.getType().getKey().getKey();
        for (var en : PRESETS.entrySet()) if (name.equals(en.getKey()) || name.endsWith("_" + en.getKey())) return en.getValue();
        return List.of();
    }

    @Override public boolean meetsRequirement(Player p) { return missing(p.getInventory().getItemInMainHand(), presetFor(p.getInventory().getItemInMainHand())) > 0; }
    @Override public String requirementMessage() { return "Hold an item that can still be enchanted further!"; }

    @Override
    public void runUltimate(Player p, Runnable done) {
        ItemStack item = p.getInventory().getItemInMainHand();
        if (apply(item, presetFor(item)) > 0) {
            p.getInventory().setItemInMainHand(item);
            Util.sound(p.getLocation(), "block.enchantment_table.use");
        }
        done.run();
    }

    // ---- passivas ----
    @EventHandler(priority = EventPriority.HIGH)
    public void onExp(PlayerExpChangeEvent e) {
        Player p = e.getPlayer();
        if (!hasPassive(p) || e.getAmount() <= 0) return;
        double total = e.getAmount() * d("passive_xp_multiplier") + leftover.getOrDefault(p.getUniqueId(), 0.0);
        int whole = (int) Math.floor(total);
        leftover.put(p.getUniqueId(), total - whole);
        e.setAmount(whole);
    }

    @Override
    public void applyPassive(Player p) {
        long now = System.currentTimeMillis();
        if (now < nextMend.getOrDefault(p.getUniqueId(), 0L)) return;
        nextMend.put(p.getUniqueId(), now + (long) (d("passive_mend_interval") * 1000));
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        List<EquipmentSlot> damaged = new ArrayList<>();
        for (EquipmentSlot s : slots) {
            ItemStack it = p.getInventory().getItem(s);
            if (it != null && it.hasItemMeta() && it.getItemMeta() instanceof Damageable dm && dm.getDamage() > 0) damaged.add(s);
        }
        if (damaged.isEmpty()) return;
        EquipmentSlot s = damaged.get(new Random().nextInt(damaged.size()));
        ItemStack it = p.getInventory().getItem(s);
        Damageable dm = (Damageable) it.getItemMeta();
        dm.setDamage(Math.max(0, dm.getDamage() - i("passive_mend_durability")));
        it.setItemMeta((ItemMeta) dm);
        p.getInventory().setItem(s, it);
    }

    @Override public void removePassive(Player p) { forget(p.getUniqueId()); }
    @Override public void onQuit(UUID id) { forget(id); }
    private void forget(UUID id) { leftover.remove(id); nextMend.remove(id); }
}
