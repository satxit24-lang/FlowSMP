package dev.flowsmp.abilities;

import dev.flowsmp.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class NetheriteAbility extends AbilityHandler {
    private static final List<String> PIECES = List.of("helmet", "chestplate", "leggings", "boots");
    private static final int MAX_RADIUS = 10;

    private record Domain(String id, String world, int x, int y, int z, int radius) {}
    private record Saved(int x, int y, int z, BlockData data) {}

    private final NamespacedKey forgedKey;
    private final Map<UUID, Integer> hitsLeft = new HashMap<>();
    private final Map<String, List<Saved>> active = new HashMap<>();
    private final Map<String, Domain> activeDomains = new HashMap<>();
    private final Set<String> protectedBlocks = new HashSet<>();
    private final Set<UUID> dying = new HashSet<>();

    public NetheriteAbility(FlowSMP plugin) {
        super(plugin);
        forgedKey = new NamespacedKey(plugin, "forged");
        Bukkit.getScheduler().runTaskTimer(plugin, () -> { for (Player p : Bukkit.getOnlinePlayers()) sweep(p); }, 10L, 10L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::clearLeftover, 100L, 100L);
    }

    @Override public Ability ability() { return Ability.NETHERITE; }

    @Override public void applyPassive(Player p) { plugin.giveEffect(p, PotionEffectType.RESISTANCE, i("passive_resistance_level")); }

    // ================= forja de armadura diamond -> netherite =================
    private String piece(Material m, String prefix) {
        String n = m.name();
        if (!n.startsWith(prefix)) return null;
        String piece = n.substring(prefix.length()).toLowerCase();
        return PIECES.contains(piece) ? piece : null;
    }

    private boolean isForged(ItemStack it) {
        return it != null && piece(it.getType(), "NETHERITE_") != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(forgedKey, PersistentDataType.BYTE);
    }

    private ItemStack convert(ItemStack item, Material to, boolean forge) {
        ItemStack c = new ItemStack(to, item.getAmount());
        ItemMeta meta = item.getItemMeta();
        if (meta instanceof Damageable dm) dm.setDamage(Math.min(dm.getDamage(), to.getMaxDurability() - 1));
        if (forge) meta.getPersistentDataContainer().set(forgedKey, PersistentDataType.BYTE, (byte) 1);
        else meta.getPersistentDataContainer().remove(forgedKey);
        c.setItemMeta(meta);
        return c;
    }

    private ItemStack revert(ItemStack it) {
        return convert(it, Material.valueOf("DIAMOND_" + piece(it.getType(), "NETHERITE_").toUpperCase()), false);
    }

    private boolean canWear(Player p) {
        return !dying.contains(p.getUniqueId()) && hasPassive(p) && b("passive_forge_diamond_armor");
    }

    private void sweep(Player p) {
        var inv = p.getInventory();
        for (int s = 0; s <= 40; s++) {
            ItemStack it = inv.getItem(s);
            if (it == null || it.getType().isAir()) continue;
            boolean forged = isForged(it);
            String dia = piece(it.getType(), "DIAMOND_");
            if (!forged && dia == null) continue;
            boolean keeps = s >= 36 && s <= 39 && canWear(p);
            if (forged && !keeps) inv.setItem(s, revert(it));
            else if (!forged && keeps) inv.setItem(s, convert(it, Material.valueOf("NETHERITE_" + dia.toUpperCase()), true));
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        dying.add(p.getUniqueId());
        try {
            ListIterator<ItemStack> it = e.getDrops().listIterator();
            while (it.hasNext()) { ItemStack s = it.next(); if (isForged(s)) it.set(revert(s)); }
            if (e.getKeepInventory()) sweep(p);
        } finally { dying.remove(p.getUniqueId()); }
    }

    @EventHandler public void onDrop(PlayerDropItemEvent e) {
        ItemStack s = e.getItemDrop().getItemStack();
        if (isForged(s)) e.getItemDrop().setItemStack(revert(s));
    }

    @EventHandler public void onClose(InventoryCloseEvent e) {
        if (e.getPlayer() instanceof Player p) Bukkit.getScheduler().runTask(plugin, () -> sweep(p));
    }

    /** Impede levar armadura forjada para fora do inventário do jogador (baús etc.). */
    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        boolean external = e.getView().getTopInventory().getType() != InventoryType.CRAFTING && e.getView().getTopInventory() != p.getInventory();
        if (!external) return;
        ItemStack cur = e.getCurrentItem(), cursor = e.getCursor();
        boolean clickedTop = e.getClickedInventory() != null && e.getClickedInventory().equals(e.getView().getTopInventory());
        if (clickedTop && isForged(cursor)) { e.setCancelled(true); return; }
        if (e.isShiftClick() && !clickedTop && isForged(cur)) { e.setCancelled(true); return; }
        if (clickedTop && e.getClick() == ClickType.NUMBER_KEY && e.getHotbarButton() >= 0 && isForged(p.getInventory().getItem(e.getHotbarButton()))) e.setCancelled(true);
    }

    // ================= ultimate: domo de obsidian =================
    private String key(String world, int x, int y, int z) { return world + "|" + x + "|" + y + "|" + z; }

    private List<int[]> shell(Domain d) {
        List<int[]> out = new ArrayList<>();
        int r = d.radius();
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            double dist = Math.sqrt(x * x + y * y + z * z);
            if (dist <= r && dist > r - 1) out.add(new int[]{d.x() + x, d.y() + y, d.z() + z});
        }
        return out;
    }

    private boolean loaded(World w, Domain d) {
        int r = d.radius();
        for (int sx : new int[]{-1, 1}) for (int sz : new int[]{-1, 1})
            if (!w.isChunkLoaded((d.x() + sx * r) >> 4, (d.z() + sz * r) >> 4)) return false;
        return true;
    }

    private boolean passable(Block b) { return b.isEmpty() || b.isLiquid() || b.isPassable(); }

    private File file() { return new File(plugin.getDataFolder(), "domains.yml"); }

    private List<Domain> saved() {
        List<Domain> out = new ArrayList<>();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file());
        for (String id : y.getKeys(false)) {
            var s = y.getConfigurationSection(id);
            if (s != null) out.add(new Domain(id, s.getString("world"), s.getInt("x"), s.getInt("y"), s.getInt("z"), s.getInt("r")));
        }
        return out;
    }

    private void save(List<Domain> list) {
        YamlConfiguration y = new YamlConfiguration();
        for (Domain d : list) {
            y.set(d.id() + ".world", d.world()); y.set(d.id() + ".x", d.x()); y.set(d.id() + ".y", d.y());
            y.set(d.id() + ".z", d.z()); y.set(d.id() + ".r", d.radius());
        }
        try { plugin.getDataFolder().mkdirs(); y.save(file()); } catch (IOException ex) { plugin.getLogger().warning("Falha ao salvar domains.yml: " + ex.getMessage()); }
    }

    private void forget(Domain d) { List<Domain> l = saved(); l.removeIf(s -> s.id().equals(d.id())); save(l); }

    private void open(Domain d) {
        World w = Bukkit.getWorld(d.world());
        List<Domain> l = saved(); l.add(d); save(l);
        List<Saved> replaced = new ArrayList<>();
        for (int[] c : shell(d)) {
            protectedBlocks.add(key(d.world(), c[0], c[1], c[2]));
            if (c[1] < w.getMinHeight() || c[1] >= w.getMaxHeight() || !w.isChunkLoaded(c[0] >> 4, c[2] >> 4)) continue;
            Block b = w.getBlockAt(c[0], c[1], c[2]);
            if (!passable(b)) continue;
            replaced.add(new Saved(c[0], c[1], c[2], b.getBlockData()));
            b.setType(Material.OBSIDIAN, false);
        }
        active.put(d.id(), replaced);
        activeDomains.put(d.id(), d);
        w.playSound(new Location(w, d.x(), d.y(), d.z()), "minecraft:block.beacon.power_select", SoundCategory.PLAYERS, 1f, 1f);
    }

    private void close(Domain d) {
        World w = Bukkit.getWorld(d.world());
        List<Saved> replaced = active.remove(d.id());
        activeDomains.remove(d.id());
        for (int[] c : shell(d)) protectedBlocks.remove(key(d.world(), c[0], c[1], c[2]));
        if (w == null || replaced == null || !loaded(w, d)) return;
        for (Saved s : replaced) {
            Block b = w.getBlockAt(s.x(), s.y(), s.z());
            if (b.getType() == Material.OBSIDIAN) b.setBlockData(s.data(), false);
        }
        forget(d);
    }

    private void clearLeftover() {
        for (Domain d : saved()) {
            World w = Bukkit.getWorld(d.world());
            if (w == null || active.containsKey(d.id()) || !loaded(w, d)) continue;
            for (int[] c : shell(d)) {
                Block b = w.getBlockAt(c[0], c[1], c[2]);
                if (b.getType() == Material.OBSIDIAN) b.setType(Material.AIR, false);
            }
            forget(d);
        }
    }

    @Override public boolean meetsRequirement(Player p) { return Util.findTarget(p, d("ultimate_pull_range")) != null; }
    @Override public String requirementMessage() { return "There is nothing close enough to pull into your domain!"; }

    @Override
    public void runUltimate(Player p, Runnable done) {
        UUID id = p.getUniqueId();
        LivingEntity target = Util.findTarget(p, d("ultimate_pull_range"));
        Location c = p.getLocation();
        Domain domain = new Domain(id + ":" + Bukkit.getCurrentTick(), c.getWorld().getName(), c.getBlockX(), c.getBlockY(), c.getBlockZ(),
                Math.min((int) Math.floor(d("ultimate_domain_radius")), MAX_RADIUS));
        hitsLeft.put(id, i("ultimate_invincible_hits"));
        if (target != null) { target.teleport(p.getLocation()); Util.sound(p.getLocation(), "entity.enderman.teleport"); }
        open(domain);
        Util.every(plugin, 5, ticks("ultimate_duration"),
                t -> Util.alive(p) && p.getWorld().getName().equals(domain.world())
                        && p.getLocation().distance(new Location(p.getWorld(), domain.x(), domain.y(), domain.z())) <= domain.radius() + 1,
                () -> { hitsLeft.remove(id); close(domain); done.run(); });
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHurt(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Integer left = hitsLeft.get(victim.getUniqueId());
        if (left == null || left <= 0) return;
        e.setCancelled(true);
        hitsLeft.put(victim.getUniqueId(), left - 1);
        victim.sendActionBar(Ability.NETHERITE.prefix(plugin.icons()).append(Component.text((left - 1) + " BLOCKED HITS LEFT", Ability.NETHERITE.color(), TextDecoration.BOLD)));
        Util.sound(victim.getLocation(), "item.shield.block");
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (protectedBlocks.contains(key(b.getWorld().getName(), b.getX(), b.getY(), b.getZ()))) e.setCancelled(true);
    }

    @Override public void onQuit(UUID id) { hitsLeft.remove(id); }

    @Override public void shutdown() {
        for (Domain d : new ArrayList<>(activeDomains.values())) close(d);
    }
}
