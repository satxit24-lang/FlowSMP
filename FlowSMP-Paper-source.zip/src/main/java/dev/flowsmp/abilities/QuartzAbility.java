package dev.flowsmp.abilities;

import dev.flowsmp.*;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public final class QuartzAbility extends AbilityHandler {
    public QuartzAbility(FlowSMP plugin) { super(plugin); }
    @Override public Ability ability() { return Ability.QUARTZ; }

    @Override public void applyPassive(Player p) { plugin.giveEffect(p, PotionEffectType.WEAVING, i("passive_weaving_level")); }

    private Block[] body(Location loc) { return new Block[]{loc.getBlock(), loc.clone().add(0, 1, 0).getBlock()}; }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        Player att = Util.meleeAttacker(e);
        if (att == null || !hasPassive(att)) return;
        for (Block bl : body(e.getEntity().getLocation())) {
            if (bl.getType() == Material.COBWEB) { e.setDamage(e.getDamage() * d("passive_cobweb_damage_multiplier")); return; }
        }
    }

    @Override public boolean meetsRequirement(Player p) { return Util.findTarget(p, d("ultimate_pull_range")) != null; }
    @Override public String requirementMessage() { return "There is nothing close enough to pull!"; }

    @Override
    public void runUltimate(Player p, Runnable done) {
        LivingEntity target = Util.findTarget(p, d("ultimate_pull_range"));
        if (target == null) { done.run(); return; }
        Vector view = p.getLocation().getDirection();
        double len = Math.hypot(view.getX(), view.getZ());
        if (len == 0) len = 1;
        Location front = p.getLocation().clone().add(view.getX() / len * d("ultimate_pull_distance"), 0, view.getZ() / len * d("ultimate_pull_distance"));
        boolean room = true;
        for (Block bl : body(front)) if (!bl.isEmpty()) room = false;
        Location dest = room ? front : p.getLocation();
        target.teleport(dest);
        for (Block bl : body(dest)) if (bl.isEmpty()) { bl.setType(Material.COBWEB); break; }
        Util.sound(dest, "entity.spider.ambient");
        done.run();
    }
}
