package dev.flowsmp.abilities;

import dev.flowsmp.*;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffectType;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class RedstoneAbility extends AbilityHandler {
    private final Set<UUID> critting = new HashSet<>();
    public RedstoneAbility(FlowSMP plugin) { super(plugin); }
    @Override public Ability ability() { return Ability.REDSTONE; }

    @Override public void applyPassive(Player p) { plugin.giveEffect(p, PotionEffectType.STRENGTH, i("passive_strength_level")); }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof AbstractArrow arrow && arrow.isShotFromCrossbow() && arrow.getShooter() instanceof Player shooter && hasPassive(shooter)) {
            int level = i("passive_crossbow_power_level");
            if (level > 0) e.setDamage(e.getDamage() * (1 + 0.25 * (level + 1)));
            return;
        }
        Player att = Util.meleeAttacker(e);
        if (att == null || !critting.contains(att.getUniqueId()) || e.isCritical()) return;
        e.setDamage(e.getDamage() * d("ultimate_crit_damage_multiplier"));
        var victim = e.getEntity();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!victim.isValid()) return;
            Util.particle(Util.Beam.body(victim), Particle.CRIT);
            Util.sound(victim.getLocation(), "entity.player.attack.crit");
        });
    }

    @Override
    public void runUltimate(Player p, Runnable done) {
        Util.Beam beam = Util.Beam.of(p, d("ultimate_beam_range"), true);
        beam.draw(Particle.SONIC_BOOM, 1, 0);
        Util.sound(p.getLocation(), "entity.warden.sonic_boom");
        for (LivingEntity t : beam.targets(p, d("ultimate_beam_width"))) {
            Util.knockAway(t, p.getLocation(), 1.5);
            Util.damage(t, d("ultimate_beam_damage"), DamageType.SONIC_BOOM, p);
        }
        UUID id = p.getUniqueId();
        critting.add(id);
        Bukkit.getScheduler().runTaskLater(plugin, () -> { critting.remove(id); done.run(); }, ticks("ultimate_duration"));
    }

    @Override public void onQuit(UUID id) { critting.remove(id); }
}
