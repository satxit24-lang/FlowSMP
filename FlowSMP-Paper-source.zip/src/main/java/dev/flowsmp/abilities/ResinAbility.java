package dev.flowsmp.abilities;

import dev.flowsmp.*;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffectType;

public final class ResinAbility extends AbilityHandler {
    public ResinAbility(FlowSMP plugin) { super(plugin); }
    @Override public Ability ability() { return Ability.RESIN; }

    @Override public void applyPassive(Player p) {
        if (b("passive_fire_resistance")) plugin.giveEffect(p, PotionEffectType.FIRE_RESISTANCE, 1);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        Player att = Util.meleeAttacker(e);
        if (att == null || !hasPassive(att) || att.getFireTicks() <= 0) return;
        e.setDamage(e.getDamage() + d("passive_burning_damage_bonus"));
    }

    @Override
    public void runUltimate(Player p, Runnable done) {
        int drained = Util.replaceNearby(p.getLocation(), d("ultimate_drain_radius"), b -> b.getType() == Material.WATER, Material.AIR);
        if (drained > 0) Util.sound(p.getLocation(), "block.fire.extinguish");
        Util.sound(p.getLocation(), "entity.ghast.shoot");
        double width = d("ultimate_beam_width");
        Util.every(plugin, 2, ticks("ultimate_duration"), t -> {
            if (!Util.alive(p)) return false;
            Util.Beam beam = Util.Beam.of(p, d("ultimate_beam_range"), false);
            beam.draw(Particle.FLAME, 0.5, width / 2);
            beam.draw(Particle.LAVA, 3, width / 2);
            if (t % 10 == 0) {
                for (LivingEntity target : beam.targets(p, width)) {
                    Util.damage(target, d("ultimate_beam_damage"), DamageType.ON_FIRE, p);
                    target.setFireTicks((int) (d("ultimate_burn_duration") * Util.TPS));
                }
            }
            return true;
        }, done);
    }
}
